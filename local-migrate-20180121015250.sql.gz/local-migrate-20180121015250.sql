# WordPress MySQL database migration
#
# Generated: Sunday 21. January 2018 01:52 UTC
# Hostname: localhost
# Database: `local`
# URL: nuevo.com
# Path: /app/public
# Tables: wp_commentmeta, wp_comments, wp_links, wp_options, wp_postmeta, wp_posts, wp_term_relationships, wp_term_taxonomy, wp_termmeta, wp_terms, wp_usermeta, wp_users
# Table Prefix: wp_
# Post Types: revision, acf, attachment, campus, event, like, nav_menu_item, note, page, post, professor, program
# Protocol: http
# Multisite: false
# Subsite Export: false
# --------------------------------------------------------

/*!40101 SET NAMES utf8 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_commentmeta`
#

#
# End of data contents of table `wp_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_comments`
#
INSERT INTO `wp_comments` ( `comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'A WordPress Commenter', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2017-12-14 00:36:08', '2017-12-14 00:36:08', 'Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href="https://gravatar.com">Gravatar</a>.', 0, '1', '', '', 0, 0) ;

#
# End of data contents of table `wp_comments`
# --------------------------------------------------------



#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_links`
#

#
# End of data contents of table `wp_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=489 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_options`
#
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http:nuevo.com', 'yes'),
(2, 'home', 'http:nuevo.com', 'yes'),
(3, 'blogname', 'Amazing College', 'yes'),
(4, 'blogdescription', 'Just another WordPress site', 'yes'),
(5, 'users_can_register', '1', 'yes'),
(6, 'admin_email', 'donotrreply@gmail.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '1', 'yes'),
(22, 'posts_per_page', '1', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:174:{s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:21:"^index.php/wp-json/?$";s:22:"index.php?rest_route=/";s:24:"^index.php/wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:11:"campuses/?$";s:26:"index.php?post_type=campus";s:41:"campuses/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?post_type=campus&feed=$matches[1]";s:36:"campuses/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?post_type=campus&feed=$matches[1]";s:28:"campuses/page/([0-9]{1,})/?$";s:44:"index.php?post_type=campus&paged=$matches[1]";s:9:"events/?$";s:25:"index.php?post_type=event";s:39:"events/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?post_type=event&feed=$matches[1]";s:34:"events/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?post_type=event&feed=$matches[1]";s:26:"events/page/([0-9]{1,})/?$";s:43:"index.php?post_type=event&paged=$matches[1]";s:11:"programs/?$";s:27:"index.php?post_type=program";s:41:"programs/feed/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?post_type=program&feed=$matches[1]";s:36:"programs/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?post_type=program&feed=$matches[1]";s:28:"programs/page/([0-9]{1,})/?$";s:45:"index.php?post_type=program&paged=$matches[1]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:36:"campuses/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:46:"campuses/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:66:"campuses/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:61:"campuses/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:61:"campuses/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:42:"campuses/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:25:"campuses/([^/]+)/embed/?$";s:39:"index.php?campus=$matches[1]&embed=true";s:29:"campuses/([^/]+)/trackback/?$";s:33:"index.php?campus=$matches[1]&tb=1";s:49:"campuses/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:45:"index.php?campus=$matches[1]&feed=$matches[2]";s:44:"campuses/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:45:"index.php?campus=$matches[1]&feed=$matches[2]";s:37:"campuses/([^/]+)/page/?([0-9]{1,})/?$";s:46:"index.php?campus=$matches[1]&paged=$matches[2]";s:44:"campuses/([^/]+)/comment-page-([0-9]{1,})/?$";s:46:"index.php?campus=$matches[1]&cpage=$matches[2]";s:33:"campuses/([^/]+)(?:/([0-9]+))?/?$";s:45:"index.php?campus=$matches[1]&page=$matches[2]";s:25:"campuses/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:35:"campuses/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:55:"campuses/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:50:"campuses/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:50:"campuses/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:31:"campuses/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:34:"events/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:44:"events/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:64:"events/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:59:"events/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:59:"events/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:40:"events/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:23:"events/([^/]+)/embed/?$";s:38:"index.php?event=$matches[1]&embed=true";s:27:"events/([^/]+)/trackback/?$";s:32:"index.php?event=$matches[1]&tb=1";s:47:"events/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?event=$matches[1]&feed=$matches[2]";s:42:"events/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?event=$matches[1]&feed=$matches[2]";s:35:"events/([^/]+)/page/?([0-9]{1,})/?$";s:45:"index.php?event=$matches[1]&paged=$matches[2]";s:42:"events/([^/]+)/comment-page-([0-9]{1,})/?$";s:45:"index.php?event=$matches[1]&cpage=$matches[2]";s:31:"events/([^/]+)(?:/([0-9]+))?/?$";s:44:"index.php?event=$matches[1]&page=$matches[2]";s:23:"events/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:33:"events/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:53:"events/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:48:"events/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:48:"events/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:29:"events/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:36:"programs/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:46:"programs/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:66:"programs/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:61:"programs/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:61:"programs/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:42:"programs/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:25:"programs/([^/]+)/embed/?$";s:40:"index.php?program=$matches[1]&embed=true";s:29:"programs/([^/]+)/trackback/?$";s:34:"index.php?program=$matches[1]&tb=1";s:49:"programs/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:46:"index.php?program=$matches[1]&feed=$matches[2]";s:44:"programs/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:46:"index.php?program=$matches[1]&feed=$matches[2]";s:37:"programs/([^/]+)/page/?([0-9]{1,})/?$";s:47:"index.php?program=$matches[1]&paged=$matches[2]";s:44:"programs/([^/]+)/comment-page-([0-9]{1,})/?$";s:47:"index.php?program=$matches[1]&cpage=$matches[2]";s:33:"programs/([^/]+)(?:/([0-9]+))?/?$";s:46:"index.php?program=$matches[1]&page=$matches[2]";s:25:"programs/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:35:"programs/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:55:"programs/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:50:"programs/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:50:"programs/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:31:"programs/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:37:"professor/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:47:"professor/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:67:"professor/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:62:"professor/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:62:"professor/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:43:"professor/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:26:"professor/([^/]+)/embed/?$";s:42:"index.php?professor=$matches[1]&embed=true";s:30:"professor/([^/]+)/trackback/?$";s:36:"index.php?professor=$matches[1]&tb=1";s:38:"professor/([^/]+)/page/?([0-9]{1,})/?$";s:49:"index.php?professor=$matches[1]&paged=$matches[2]";s:45:"professor/([^/]+)/comment-page-([0-9]{1,})/?$";s:49:"index.php?professor=$matches[1]&cpage=$matches[2]";s:34:"professor/([^/]+)(?:/([0-9]+))?/?$";s:48:"index.php?professor=$matches[1]&page=$matches[2]";s:26:"professor/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:36:"professor/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:56:"professor/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:51:"professor/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:51:"professor/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:32:"professor/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:12:"robots\\.txt$";s:18:"index.php?robots=1";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:39:"index.php?&page_id=30&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:27:"[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:"[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"([^/]+)/embed/?$";s:37:"index.php?name=$matches[1]&embed=true";s:20:"([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:40:"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:35:"([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:28:"([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:35:"([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:24:"([^/]+)(?:/([0-9]+))?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:16:"[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:26:"[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:46:"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:22:"[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:6:{i:0;s:30:"advanced-custom-fields/acf.php";i:1;s:51:"all-in-one-wp-migration/all-in-one-wp-migration.php";i:2;s:39:"manual-image-crop/manual-image-crop.php";i:3;s:19:"members/members.php";i:4;s:47:"regenerate-thumbnails/regenerate-thumbnails.php";i:5;s:31:"wp-migrate-db/wp-migrate-db.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'fictional-university-theme', 'yes'),
(41, 'stylesheet', 'fictional-university-theme', 'yes'),
(42, 'comment_whitelist', '1', 'yes'),
(43, 'blacklist_keys', '', 'no'),
(44, 'comment_registration', '0', 'yes'),
(45, 'html_type', 'text/html', 'yes'),
(46, 'use_trackback', '0', 'yes'),
(47, 'default_role', 'subscriber', 'yes'),
(48, 'db_version', '38590', 'yes'),
(49, 'uploads_use_yearmonth_folders', '1', 'yes'),
(50, 'upload_path', '', 'yes'),
(51, 'blog_public', '1', 'yes'),
(52, 'default_link_category', '2', 'yes'),
(53, 'show_on_front', 'page', 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', '1', 'yes'),
(56, 'avatar_rating', 'G', 'yes'),
(57, 'upload_url_path', '', 'yes'),
(58, 'thumbnail_size_w', '150', 'yes'),
(59, 'thumbnail_size_h', '150', 'yes'),
(60, 'thumbnail_crop', '1', 'yes'),
(61, 'medium_size_w', '300', 'yes'),
(62, 'medium_size_h', '300', 'yes'),
(63, 'avatar_default', 'mystery', 'yes'),
(64, 'large_size_w', '1024', 'yes'),
(65, 'large_size_h', '1024', 'yes'),
(66, 'image_default_link_type', 'none', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '0', 'yes'),
(70, 'close_comments_days_old', '14', 'yes'),
(71, 'thread_comments', '1', 'yes'),
(72, 'thread_comments_depth', '5', 'yes'),
(73, 'page_comments', '0', 'yes'),
(74, 'comments_per_page', '50', 'yes'),
(75, 'default_comments_page', 'newest', 'yes'),
(76, 'comment_order', 'asc', 'yes'),
(77, 'sticky_posts', 'a:0:{}', 'yes'),
(78, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(79, 'widget_text', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(80, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(81, 'uninstall_plugins', 'a:0:{}', 'no'),
(82, 'timezone_string', '', 'yes'),
(83, 'page_for_posts', '32', 'yes'),
(84, 'page_on_front', '30', 'yes'),
(85, 'default_post_format', '0', 'yes'),
(86, 'link_manager_enabled', '0', 'yes'),
(87, 'finished_splitting_shared_terms', '1', 'yes'),
(88, 'site_icon', '0', 'yes'),
(89, 'medium_large_size_w', '768', 'yes'),
(90, 'medium_large_size_h', '0', 'yes'),
(91, 'initial_db_version', '38590', 'yes'),
(92, 'wp_user_roles', 'a:7:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:86:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:16:"restrict_content";b:1;s:10:"list_roles";b:1;s:12:"create_roles";b:1;s:12:"delete_roles";b:1;s:10:"edit_roles";b:1;s:13:"delete_events";b:1;s:20:"delete_others_events";b:1;s:21:"delete_private_events";b:1;s:23:"delete_published_events";b:1;s:11:"edit_events";b:1;s:18:"edit_others_events";b:1;s:19:"edit_private_events";b:1;s:21:"edit_published_events";b:1;s:14:"publish_events";b:1;s:19:"read_private_events";b:1;s:14:"delete_campuss";b:1;s:21:"delete_others_campuss";b:1;s:22:"delete_private_campuss";b:1;s:24:"delete_published_campuss";b:1;s:12:"edit_campuss";b:1;s:19:"edit_others_campuss";b:1;s:20:"edit_private_campuss";b:1;s:22:"edit_published_campuss";b:1;s:15:"publish_campuss";b:1;s:20:"read_private_campuss";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:5:{s:4:"read";b:1;s:7:"level_0";b:1;s:10:"edit_notes";b:1;s:13:"publish_notes";b:1;s:12:"delete_notes";b:1;}}s:13:"event_planner";a:2:{s:4:"name";s:13:"Event Planner";s:12:"capabilities";a:11:{s:4:"read";b:1;s:11:"edit_events";b:1;s:18:"edit_others_events";b:1;s:14:"publish_events";b:1;s:19:"read_private_events";b:1;s:13:"delete_events";b:1;s:21:"delete_private_events";b:1;s:23:"delete_published_events";b:1;s:20:"delete_others_events";b:1;s:19:"edit_private_events";b:1;s:21:"edit_published_events";b:1;}}s:14:"campus_manager";a:2:{s:4:"name";s:14:"Campus Manager";s:12:"capabilities";a:11:{s:4:"read";b:1;s:12:"edit_campuss";b:1;s:19:"edit_others_campuss";b:1;s:15:"publish_campuss";b:1;s:20:"read_private_campuss";b:1;s:14:"delete_campuss";b:1;s:22:"delete_private_campuss";b:1;s:24:"delete_published_campuss";b:1;s:21:"delete_others_campuss";b:1;s:20:"edit_private_campuss";b:1;s:22:"edit_published_campuss";b:1;}}}', 'yes'),
(93, 'fresh_site', '0', 'yes'),
(94, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(95, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(96, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(97, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(98, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(99, 'sidebars_widgets', 'a:3:{s:19:"wp_inactive_widgets";a:0:{}s:18:"orphaned_widgets_1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:13:"array_version";i:3;}', 'yes'),
(100, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(101, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(102, 'widget_media_audio', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(103, 'widget_media_image', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(104, 'widget_media_video', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(106, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(107, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(108, 'widget_custom_html', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(109, 'cron', 'a:6:{i:1515933378;a:1:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1515933379;a:1:{s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1515933380;a:2:{s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1515961872;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1515981559;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}s:7:"version";i:2;}', 'yes'),
(111, 'nonce_key', 'KPZ`A6fA13MtWGd5wl|ZB<P|5dBA.q} rh.Hd>`X[V/4D+TQ@a!$BC4}fS5J?x[F', 'no'),
(112, 'nonce_salt', '-o}eyzSZtLOITXGe,Y6A:4!xHbTbK7pTG-x:s*>GD,aO)K0qi;oWk,q-Rw,cn!E]', 'no'),
(114, 'theme_mods_twentyseventeen', 'a:2:{s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1513735086;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}s:9:"sidebar-3";a:0:{}}}}', 'yes'),
(126, 'auto_core_update_notified', 'a:4:{s:4:"type";s:7:"success";s:5:"email";s:21:"donotrreply@gmail.com";s:7:"version";s:5:"4.8.4";s:9:"timestamp";i:1513211837;}', 'no'),
(137, 'can_compress_scripts', '1', 'no'),
(171, 'current_theme', 'Fictional University', 'yes'),
(172, 'theme_mods_fictional-university-theme', 'a:3:{i:0;b:0;s:18:"custom_css_post_id";i:-1;s:18:"nav_menu_locations";a:1:{s:18:"headerMenuLocation";i:2;}}', 'yes'),
(173, 'theme_switched', '', 'yes'),
(221, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes'),
(234, 'category_children', 'a:0:{}', 'yes'),
(267, 'recently_activated', 'a:0:{}', 'yes'),
(274, 'acf_version', '4.4.12', 'yes'),
(344, 'mic_make2x', 'true', 'yes'),
(432, 'WPLANG', '', 'yes'),
(485, 'ai1wm_secret_key', 'bF8Pt6jH2bih', 'yes'),
(486, 'wpmdb_usage', 'a:2:{s:6:"action";s:8:"savefile";s:4:"time";i:1516499570;}', 'no') ;

#
# End of data contents of table `wp_options`
# --------------------------------------------------------



#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=311 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_postmeta`
#
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 4, '_edit_last', '1'),
(3, 4, '_edit_lock', '1513736778:1'),
(6, 6, '_edit_last', '1'),
(7, 6, '_edit_lock', '1513741052:1'),
(8, 9, '_edit_last', '1'),
(9, 9, '_edit_lock', '1514338171:1'),
(10, 11, '_edit_last', '1'),
(11, 11, '_edit_lock', '1514337708:1'),
(12, 13, '_edit_last', '1'),
(13, 13, '_edit_lock', '1514337757:1'),
(14, 16, '_edit_last', '1'),
(15, 16, '_edit_lock', '1514338713:1'),
(16, 18, '_edit_last', '1'),
(17, 18, '_edit_lock', '1514423313:1'),
(27, 21, '_menu_item_type', 'post_type'),
(28, 21, '_menu_item_menu_item_parent', '0'),
(29, 21, '_menu_item_object_id', '9'),
(30, 21, '_menu_item_object', 'page'),
(31, 21, '_menu_item_target', ''),
(32, 21, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(33, 21, '_menu_item_xfn', ''),
(34, 21, '_menu_item_url', ''),
(54, 24, '_menu_item_type', 'post_type'),
(55, 24, '_menu_item_menu_item_parent', '0'),
(56, 24, '_menu_item_object_id', '11'),
(57, 24, '_menu_item_object', 'page'),
(58, 24, '_menu_item_target', ''),
(59, 24, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(60, 24, '_menu_item_xfn', ''),
(61, 24, '_menu_item_url', ''),
(90, 28, '_menu_item_type', 'post_type'),
(91, 28, '_menu_item_menu_item_parent', '0'),
(92, 28, '_menu_item_object_id', '11'),
(93, 28, '_menu_item_object', 'page'),
(94, 28, '_menu_item_target', ''),
(95, 28, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(96, 28, '_menu_item_xfn', ''),
(97, 28, '_menu_item_url', ''),
(98, 28, '_menu_item_orphaned', '1514423545'),
(99, 29, '_menu_item_type', 'post_type'),
(100, 29, '_menu_item_menu_item_parent', '0'),
(101, 29, '_menu_item_object_id', '9'),
(102, 29, '_menu_item_object', 'page'),
(103, 29, '_menu_item_target', ''),
(104, 29, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(105, 29, '_menu_item_xfn', ''),
(106, 29, '_menu_item_url', ''),
(107, 29, '_menu_item_orphaned', '1514423546'),
(108, 30, '_edit_last', '1'),
(109, 30, '_edit_lock', '1514506485:1'),
(110, 32, '_edit_last', '1'),
(111, 32, '_edit_lock', '1514506631:1'),
(112, 34, '_edit_last', '1'),
(113, 34, '_edit_lock', '1514509138:1'),
(114, 36, '_edit_last', '1'),
(115, 36, '_edit_lock', '1514753528:1'),
(116, 37, '_edit_last', '1'),
(117, 37, '_edit_lock', '1515195343:1'),
(118, 38, '_edit_last', '1'),
(119, 38, '_edit_lock', '1515294467:1'),
(120, 41, '_edit_last', '1'),
(121, 41, 'field_5a4830c91f942', 'a:11:{s:3:"key";s:19:"field_5a4830c91f942";s:5:"label";s:10:"Event Date";s:4:"name";s:10:"event_date";s:4:"type";s:11:"date_picker";s:12:"instructions";s:0:"";s:8:"required";s:1:"1";s:11:"date_format";s:6:"yymmdd";s:14:"display_format";s:8:"dd/mm/yy";s:9:"first_day";s:1:"1";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:2:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:0;}'),
(122, 41, 'rule', 'a:5:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:5:"event";s:8:"order_no";i:0;s:8:"group_no";i:0;}'),
(123, 41, 'position', 'normal'),
(124, 41, 'layout', 'no_box'),
(125, 41, 'hide_on_screen', ''),
(126, 41, '_edit_lock', '1514680543:1'),
(127, 38, 'event_date', '20180728'),
(128, 38, '_event_date', 'field_5a4830c91f942'),
(129, 37, 'event_date', '20181230'),
(130, 37, '_event_date', 'field_5a4830c91f942'),
(131, 36, 'event_date', '20181230'),
(132, 36, '_event_date', 'field_5a4830c91f942'),
(133, 42, '_edit_last', '1'),
(134, 42, '_edit_lock', '1514752896:1'),
(135, 46, '_edit_last', '1'),
(136, 46, '_edit_lock', '1515375072:1'),
(137, 47, '_edit_last', '1'),
(138, 47, '_edit_lock', '1515103778:1'),
(139, 48, '_edit_last', '1'),
(140, 48, '_edit_lock', '1515964363:1'),
(141, 49, '_edit_last', '1'),
(142, 49, '_edit_lock', '1515099797:1'),
(143, 50, '_edit_last', '1'),
(144, 50, '_edit_lock', '1515099810:1'),
(145, 51, '_edit_last', '1'),
(146, 51, 'field_5a4ea510adf9e', 'a:14:{s:3:"key";s:19:"field_5a4ea510adf9e";s:5:"label";s:18:"Related Program(s)";s:4:"name";s:16:"related_programs";s:4:"type";s:12:"relationship";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:13:"return_format";s:6:"object";s:9:"post_type";a:1:{i:0;s:7:"program";}s:8:"taxonomy";a:1:{i:0;s:3:"all";}s:7:"filters";a:1:{i:0;s:6:"search";}s:15:"result_elements";a:1:{i:0;s:9:"post_type";}s:3:"max";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:2:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:0;}'),
(148, 51, 'position', 'normal'),
(149, 51, 'layout', 'no_box'),
(150, 51, 'hide_on_screen', ''),
(151, 51, '_edit_lock', '1515199432:1'),
(152, 50, '_wp_trash_meta_status', 'publish'),
(153, 50, '_wp_trash_meta_time', '1515103728'),
(154, 50, '_wp_desired_post_slug', '555'),
(155, 49, '_wp_trash_meta_status', 'publish'),
(156, 49, '_wp_trash_meta_time', '1515103732'),
(157, 49, '_wp_desired_post_slug', '4'),
(158, 48, '_wp_old_slug', '3'),
(159, 47, '_wp_old_slug', '2') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(160, 46, '_wp_old_slug', '1'),
(161, 37, 'related_programs', 'a:1:{i:0;s:2:"48";}'),
(162, 37, '_related_programs', 'field_5a4ea510adf9e'),
(163, 52, '_edit_last', '1'),
(164, 52, '_edit_lock', '1515198573:1'),
(165, 53, '_edit_last', '1'),
(166, 53, '_edit_lock', '1515213363:1'),
(167, 51, 'rule', 'a:5:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:5:"event";s:8:"order_no";i:0;s:8:"group_no";i:0;}'),
(168, 51, 'rule', 'a:5:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:9:"professor";s:8:"order_no";i:0;s:8:"group_no";i:1;}'),
(169, 53, 'related_programs', 'a:1:{i:0;s:2:"48";}'),
(170, 53, '_related_programs', 'field_5a4ea510adf9e'),
(171, 54, '_wp_attached_file', '2018/01/barksalot.jpg'),
(172, 54, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:6000;s:6:"height";i:4000;s:4:"file";s:21:"2018/01/barksalot.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"barksalot-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:21:"barksalot-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:21:"barksalot-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:22:"barksalot-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:18:"professorLandscape";a:4:{s:4:"file";s:21:"barksalot-400x260.jpg";s:5:"width";i:400;s:6:"height";i:260;s:9:"mime-type";s:10:"image/jpeg";}s:17:"professorPortrait";a:4:{s:4:"file";s:21:"barksalot-480x650.jpg";s:5:"width";i:480;s:6:"height";i:650;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(173, 53, '_thumbnail_id', '54'),
(174, 55, '_wp_attached_file', '2018/01/meowsalot.jpg'),
(175, 55, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:4896;s:6:"height";i:3264;s:4:"file";s:21:"2018/01/meowsalot.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"meowsalot-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:21:"meowsalot-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:21:"meowsalot-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:22:"meowsalot-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:18:"professorLandscape";a:4:{s:4:"file";s:21:"meowsalot-400x260.jpg";s:5:"width";i:400;s:6:"height";i:260;s:9:"mime-type";s:10:"image/jpeg";}s:17:"professorPortrait";a:4:{s:4:"file";s:21:"meowsalot-480x650.jpg";s:5:"width";i:480;s:6:"height";i:650;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(176, 52, '_thumbnail_id', '55'),
(177, 52, 'related_programs', 'a:1:{i:0;s:2:"48";}'),
(178, 52, '_related_programs', 'field_5a4ea510adf9e'),
(179, 56, '_edit_last', '1'),
(180, 56, '_edit_lock', '1515199547:1'),
(181, 57, '_wp_attached_file', '2018/01/frog-bio.jpg'),
(182, 57, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:7598;s:6:"height";i:5933;s:4:"file";s:20:"2018/01/frog-bio.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:20:"frog-bio-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:20:"frog-bio-300x234.jpg";s:5:"width";i:300;s:6:"height";i:234;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:20:"frog-bio-768x600.jpg";s:5:"width";i:768;s:6:"height";i:600;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:21:"frog-bio-1024x800.jpg";s:5:"width";i:1024;s:6:"height";i:800;s:9:"mime-type";s:10:"image/jpeg";}s:18:"professorLandscape";a:4:{s:4:"file";s:20:"frog-bio-400x260.jpg";s:5:"width";i:400;s:6:"height";i:260;s:9:"mime-type";s:10:"image/jpeg";}s:17:"professorPortrait";a:4:{s:4:"file";s:20:"frog-bio-480x650.jpg";s:5:"width";i:480;s:6:"height";i:650;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(183, 56, '_thumbnail_id', '57'),
(184, 56, 'related_programs', 'a:1:{i:0;s:2:"46";}'),
(185, 56, '_related_programs', 'field_5a4ea510adf9e'),
(186, 58, '_edit_last', '1'),
(187, 58, 'field_5a502685207f6', 'a:14:{s:3:"key";s:19:"field_5a502685207f6";s:5:"label";s:20:"Page Banner Subtitle";s:4:"name";s:20:"page_banner_subtitle";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:10:"formatting";s:4:"html";s:9:"maxlength";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:2:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:0;}'),
(188, 58, 'field_5a5026a7207f7', 'a:11:{s:3:"key";s:19:"field_5a5026a7207f7";s:5:"label";s:28:"Page Banner Background Image";s:4:"name";s:28:"page_banner_background_image";s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:11:"save_format";s:6:"object";s:12:"preview_size";s:9:"thumbnail";s:7:"library";s:3:"all";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:1;}'),
(191, 58, 'position', 'normal'),
(192, 58, 'layout', 'no_box'),
(193, 58, 'hide_on_screen', ''),
(194, 58, '_edit_lock', '1515202526:1'),
(195, 59, '_wp_attached_file', '2018/01/field.jpg'),
(196, 59, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2784;s:6:"height";i:1856;s:4:"file";s:17:"2018/01/field.jpg";s:5:"sizes";a:7:{s:9:"thumbnail";a:4:{s:4:"file";s:17:"field-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:17:"field-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:17:"field-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:18:"field-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:18:"professorLandscape";a:4:{s:4:"file";s:17:"field-400x260.jpg";s:5:"width";i:400;s:6:"height";i:260;s:9:"mime-type";s:10:"image/jpeg";}s:17:"professorPortrait";a:4:{s:4:"file";s:17:"field-480x650.jpg";s:5:"width";i:480;s:6:"height";i:650;s:9:"mime-type";s:10:"image/jpeg";}s:10:"pageBanner";a:4:{s:4:"file";s:18:"field-1500x350.jpg";s:5:"width";i:1500;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(197, 53, 'page', 'The leading voice on barking biology'),
(198, 53, '_page', 'field_5a502685207f6'),
(199, 53, 'page_banner_background_image', '59'),
(200, 53, '_page_banner_background_image', 'field_5a5026a7207f7'),
(201, 58, 'rule', 'a:5:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:4:"post";s:8:"order_no";i:0;s:8:"group_no";i:0;}'),
(202, 58, 'rule', 'a:5:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"!=";s:5:"value";s:4:"post";s:8:"order_no";i:0;s:8:"group_no";i:1;}'),
(203, 53, 'page_banner_subtitle', 'The leading voice on barking biology'),
(204, 53, '_page_banner_subtitle', 'field_5a502685207f6'),
(205, 60, '_wp_attached_file', '2017/12/notebook.jpg'),
(206, 60, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:4592;s:6:"height";i:3448;s:4:"file";s:20:"2017/12/notebook.jpg";s:5:"sizes";a:7:{s:9:"thumbnail";a:4:{s:4:"file";s:20:"notebook-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:20:"notebook-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:20:"notebook-768x577.jpg";s:5:"width";i:768;s:6:"height";i:577;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:21:"notebook-1024x769.jpg";s:5:"width";i:1024;s:6:"height";i:769;s:9:"mime-type";s:10:"image/jpeg";}s:18:"professorLandscape";a:4:{s:4:"file";s:20:"notebook-400x260.jpg";s:5:"width";i:400;s:6:"height";i:260;s:9:"mime-type";s:10:"image/jpeg";}s:17:"professorPortrait";a:4:{s:4:"file";s:20:"notebook-480x650.jpg";s:5:"width";i:480;s:6:"height";i:650;s:9:"mime-type";s:10:"image/jpeg";}s:10:"pageBanner";a:4:{s:4:"file";s:21:"notebook-1500x350.jpg";s:5:"width";i:1500;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(207, 38, 'page_banner_subtitle', 'La prueba'),
(208, 38, '_page_banner_subtitle', 'field_5a502685207f6'),
(209, 38, 'page_banner_background_image', '60'),
(210, 38, '_page_banner_background_image', 'field_5a5026a7207f7'),
(211, 38, 'related_programs', ''),
(212, 38, '_related_programs', 'field_5a4ea510adf9e'),
(213, 61, '_edit_last', '1'),
(214, 61, '_edit_lock', '1515374585:1'),
(215, 61, 'page_banner_subtitle', 'A beautiful campus in the heart of downtown'),
(216, 61, '_page_banner_subtitle', 'field_5a502685207f6'),
(217, 61, 'page_banner_background_image', ''),
(218, 61, '_page_banner_background_image', 'field_5a5026a7207f7'),
(219, 62, '_edit_last', '1'),
(220, 62, '_edit_lock', '1515374583:1'),
(221, 62, 'page_banner_subtitle', ''),
(222, 62, '_page_banner_subtitle', 'field_5a502685207f6'),
(223, 62, 'page_banner_background_image', ''),
(224, 62, '_page_banner_background_image', 'field_5a5026a7207f7'),
(225, 63, '_edit_last', '1'),
(226, 63, 'field_5a52b7952752b', 'a:12:{s:3:"key";s:19:"field_5a52b7952752b";s:5:"label";s:12:"Map_Location";s:4:"name";s:12:"map_location";s:4:"type";s:10:"google_map";s:12:"instructions";s:0:"";s:8:"required";s:1:"1";s:10:"center_lat";s:0:"";s:10:"center_lng";s:0:"";s:4:"zoom";s:0:"";s:6:"height";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:2:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:0;}'),
(227, 63, 'rule', 'a:5:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:6:"campus";s:8:"order_no";i:0;s:8:"group_no";i:0;}'),
(228, 63, 'position', 'normal'),
(229, 63, 'layout', 'no_box'),
(230, 63, 'hide_on_screen', ''),
(231, 63, '_edit_lock', '1515370343:1'),
(232, 62, 'map_location', 'a:3:{s:7:"address";s:56:"243-253 Little Collins St, Melbourne VIC 3000, Australia";s:3:"lat";s:18:"-37.81449239895686";s:3:"lng";s:16:"144.966402053833";}'),
(233, 62, '_map_location', 'field_5a52b7952752b'),
(234, 61, 'map_location', 'a:3:{s:7:"address";s:51:"38-40 Dudley St, West Melbourne VIC 3003, Australia";s:3:"lat";s:18:"-37.80852520867738";s:3:"lng";s:18:"144.95387077331543";}'),
(235, 61, '_map_location', 'field_5a52b7952752b'),
(236, 65, '_edit_last', '1'),
(237, 65, 'field_5a52c93ebaa8b', 'a:14:{s:3:"key";s:19:"field_5a52c93ebaa8b";s:5:"label";s:18:"Related Campus(es)";s:4:"name";s:14:"related_campus";s:4:"type";s:12:"relationship";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:13:"return_format";s:6:"object";s:9:"post_type";a:1:{i:0;s:6:"campus";}s:8:"taxonomy";a:1:{i:0;s:3:"all";}s:7:"filters";a:1:{i:0;s:6:"search";}s:15:"result_elements";a:1:{i:0;s:9:"post_type";}s:3:"max";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:2:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:0;}'),
(238, 65, 'rule', 'a:5:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:7:"program";s:8:"order_no";i:0;s:8:"group_no";i:0;}'),
(239, 65, 'position', 'normal'),
(240, 65, 'layout', 'no_box'),
(241, 65, 'hide_on_screen', ''),
(242, 65, '_edit_lock', '1515374865:1'),
(243, 46, 'page_banner_subtitle', ''),
(244, 46, '_page_banner_subtitle', 'field_5a502685207f6'),
(245, 46, 'page_banner_background_image', ''),
(246, 46, '_page_banner_background_image', 'field_5a5026a7207f7'),
(247, 46, 'related_campus', 'a:2:{i:0;s:2:"62";i:1;s:2:"61";}'),
(248, 46, '_related_campus', 'field_5a52c93ebaa8b'),
(249, 67, '_edit_last', '1'),
(250, 67, 'field_5a5bc26916414', 'a:11:{s:3:"key";s:19:"field_5a5bc26916414";s:5:"label";s:17:"Main Body Content";s:4:"name";s:17:"main_body_content";s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:7:"toolbar";s:4:"full";s:12:"media_upload";s:3:"yes";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:2:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:0;}'),
(251, 67, 'rule', 'a:5:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:7:"program";s:8:"order_no";i:0;s:8:"group_no";i:0;}'),
(252, 67, 'position', 'acf_after_title'),
(253, 67, 'layout', 'no_box'),
(254, 67, 'hide_on_screen', ''),
(255, 67, '_edit_lock', '1515962938:1'),
(256, 48, 'main_body_content', '3333'),
(257, 48, '_main_body_content', 'field_5a5bc26916414'),
(258, 48, 'page_banner_subtitle', ''),
(259, 48, '_page_banner_subtitle', 'field_5a502685207f6'),
(260, 48, 'page_banner_background_image', ''),
(261, 48, '_page_banner_background_image', 'field_5a5026a7207f7') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(262, 48, 'related_campus', ''),
(263, 48, '_related_campus', 'field_5a52c93ebaa8b'),
(264, 68, '_edit_last', '1'),
(265, 69, 'page_banner_subtitle', ''),
(266, 69, '_page_banner_subtitle', 'field_5a502685207f6'),
(267, 69, 'page_banner_background_image', ''),
(268, 69, '_page_banner_background_image', 'field_5a5026a7207f7'),
(269, 68, 'page_banner_subtitle', ''),
(270, 68, '_page_banner_subtitle', 'field_5a502685207f6'),
(271, 68, 'page_banner_background_image', ''),
(272, 68, '_page_banner_background_image', 'field_5a5026a7207f7'),
(273, 68, '_edit_lock', '1515964446:1'),
(274, 71, '_edit_lock', '1516146145:1'),
(275, 71, '_edit_last', '1'),
(276, 72, 'page_banner_subtitle', ''),
(277, 72, '_page_banner_subtitle', 'field_5a502685207f6'),
(278, 72, 'page_banner_background_image', ''),
(279, 72, '_page_banner_background_image', 'field_5a5026a7207f7'),
(280, 71, 'page_banner_subtitle', ''),
(281, 71, '_page_banner_subtitle', 'field_5a502685207f6'),
(282, 71, 'page_banner_background_image', ''),
(283, 71, '_page_banner_background_image', 'field_5a5026a7207f7'),
(284, 73, '_edit_lock', '1516146206:1'),
(285, 73, '_edit_last', '1'),
(286, 73, 'page_banner_subtitle', ''),
(287, 73, '_page_banner_subtitle', 'field_5a502685207f6'),
(288, 73, 'page_banner_background_image', ''),
(289, 73, '_page_banner_background_image', 'field_5a5026a7207f7'),
(290, 74, '_edit_lock', '1516153135:1'),
(291, 74, '_edit_last', '1'),
(292, 74, 'page_banner_subtitle', ''),
(293, 74, '_page_banner_subtitle', 'field_5a502685207f6'),
(294, 74, 'page_banner_background_image', ''),
(295, 74, '_page_banner_background_image', 'field_5a5026a7207f7'),
(296, 75, '_edit_lock', '1516495190:1'),
(297, 75, '_edit_last', '1'),
(298, 75, 'field_5a63e1b92071b', 'a:15:{s:3:"key";s:19:"field_5a63e1b92071b";s:5:"label";s:18:"Liked Professor ID";s:4:"name";s:18:"liked_professor_id";s:4:"type";s:6:"number";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:4:"step";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:2:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:0;}'),
(299, 75, 'rule', 'a:5:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:4:"like";s:8:"order_no";i:0;s:8:"group_no";i:0;}'),
(300, 75, 'position', 'normal'),
(301, 75, 'layout', 'no_box'),
(302, 75, 'hide_on_screen', ''),
(303, 76, '_edit_lock', '1516495246:1'),
(304, 76, '_edit_last', '1'),
(305, 76, 'liked_professor_id', '53'),
(306, 76, '_liked_professor_id', 'field_5a63e1b92071b'),
(307, 76, 'page_banner_subtitle', ''),
(308, 76, '_page_banner_subtitle', 'field_5a502685207f6'),
(309, 76, 'page_banner_background_image', ''),
(310, 76, '_page_banner_background_image', 'field_5a5026a7207f7') ;

#
# End of data contents of table `wp_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_posts`
#
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2017-12-14 00:36:08', '2017-12-14 00:36:08', 'Welcome to WordPress. This is your first post. Edit or delete it, then start writing!', 'Hello world!', '', 'publish', 'open', 'open', '', 'hello-world', '', '', '2017-12-14 00:36:08', '2017-12-14 00:36:08', '', 0, 'http:nuevo.com/?p=1', 0, 'post', '', 1),
(2, 1, '2017-12-14 00:36:08', '2017-12-14 00:36:08', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\n\n<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</blockquote>\n\n...or something like this:\n\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\n\nAs a new WordPress user, you should go to <a href="http:nuevo.com/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'publish', 'closed', 'open', '', 'sample-page', '', '', '2017-12-14 00:36:08', '2017-12-14 00:36:08', '', 0, 'http:nuevo.com/?page_id=2', 0, 'page', '', 0),
(4, 1, '2017-12-20 01:59:33', '2017-12-20 01:59:33', 'ASas', 'Test 2', '', 'publish', 'open', 'open', '', 'test-2', '', '', '2017-12-20 01:59:33', '2017-12-20 01:59:33', '', 0, 'http:nuevo.com/?p=4', 0, 'post', '', 0),
(5, 1, '2017-12-20 01:59:33', '2017-12-20 01:59:33', 'ASas', 'Test 2', '', 'inherit', 'closed', 'closed', '', '4-revision-v1', '', '', '2017-12-20 01:59:33', '2017-12-20 01:59:33', '', 4, 'http:nuevo.com/4-revision-v1/', 0, 'revision', '', 0),
(6, 1, '2017-12-20 02:29:01', '2017-12-20 02:29:01', 'Lorem ipsum', 'Test Page', '', 'publish', 'closed', 'closed', '', 'test-page', '', '', '2017-12-20 02:29:01', '2017-12-20 02:29:01', '', 0, 'http:nuevo.com/?page_id=6', 0, 'page', '', 0),
(7, 1, '2017-12-20 02:29:01', '2017-12-20 02:29:01', 'Lorem ipsum', 'Test Page', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2017-12-20 02:29:01', '2017-12-20 02:29:01', '', 6, 'http:nuevo.com/6-revision-v1/', 0, 'revision', '', 0),
(9, 1, '2017-12-26 01:23:17', '2017-12-26 01:23:17', 'Lorem ipsum Lorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsum', 'About Us', '', 'publish', 'closed', 'closed', '', 'about-us', '', '', '2017-12-26 01:23:17', '2017-12-26 01:23:17', '', 0, 'http:nuevo.com/?page_id=9', 0, 'page', '', 0),
(10, 1, '2017-12-26 01:23:17', '2017-12-26 01:23:17', 'Lorem ipsum Lorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsum', 'About Us', '', 'inherit', 'closed', 'closed', '', '9-revision-v1', '', '', '2017-12-26 01:23:17', '2017-12-26 01:23:17', '', 9, 'http:nuevo.com/9-revision-v1/', 0, 'revision', '', 0),
(11, 1, '2017-12-26 01:23:44', '2017-12-26 01:23:44', 'Lorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsum', 'Privacy Policy', '', 'publish', 'closed', 'closed', '', 'privacy-policy', '', '', '2017-12-26 01:23:44', '2017-12-26 01:23:44', '', 0, 'http:nuevo.com/?page_id=11', 0, 'page', '', 0),
(12, 1, '2017-12-26 01:23:44', '2017-12-26 01:23:44', 'Lorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsum', 'Privacy Policy', '', 'inherit', 'closed', 'closed', '', '11-revision-v1', '', '', '2017-12-26 01:23:44', '2017-12-26 01:23:44', '', 11, 'http:nuevo.com/11-revision-v1/', 0, 'revision', '', 0),
(13, 1, '2017-12-27 01:24:49', '2017-12-27 01:24:49', 'Lorem ipsum our story Lorem ipsum our storyLorem ipsum our storyLorem ipsum our storyLorem ipsum our storyLorem ipsum our storyLorem ipsum our storyLorem ipsum our storyLorem ipsum our storyLorem ipsum our storyLorem ipsum our storyLorem ipsum our storyLorem ipsum our story', 'Our History', '', 'publish', 'closed', 'closed', '', 'our-history', '', '', '2017-12-27 01:24:49', '2017-12-27 01:24:49', '', 9, 'http:nuevo.com/?page_id=13', 0, 'page', '', 0),
(14, 1, '2017-12-27 01:24:27', '2017-12-27 01:24:27', '', 'Our History', '', 'inherit', 'closed', 'closed', '', '13-revision-v1', '', '', '2017-12-27 01:24:27', '2017-12-27 01:24:27', '', 13, 'http:nuevo.com/13-revision-v1/', 0, 'revision', '', 0),
(15, 1, '2017-12-27 01:24:49', '2017-12-27 01:24:49', 'Lorem ipsum our story Lorem ipsum our storyLorem ipsum our storyLorem ipsum our storyLorem ipsum our storyLorem ipsum our storyLorem ipsum our storyLorem ipsum our storyLorem ipsum our storyLorem ipsum our storyLorem ipsum our storyLorem ipsum our storyLorem ipsum our story', 'Our History', '', 'inherit', 'closed', 'closed', '', '13-revision-v1', '', '', '2017-12-27 01:24:49', '2017-12-27 01:24:49', '', 13, 'http:nuevo.com/13-revision-v1/', 0, 'revision', '', 0),
(16, 1, '2017-12-27 01:25:31', '2017-12-27 01:25:31', 'Lorem ipsum our goals Lorem ipsum our goals Lorem ipsum our goals Lorem ipsum our goals Lorem ipsum our goals Lorem ipsum our goals Lorem ipsum our goals Lorem ipsum our goals Lorem ipsum our goals Lorem ipsum our goals', 'Our Goals', '', 'publish', 'closed', 'closed', '', 'our-goals', '', '', '2017-12-27 01:25:31', '2017-12-27 01:25:31', '', 9, 'http:nuevo.com/?page_id=16', 0, 'page', '', 0),
(17, 1, '2017-12-27 01:25:31', '2017-12-27 01:25:31', 'Lorem ipsum our goals Lorem ipsum our goals Lorem ipsum our goals Lorem ipsum our goals Lorem ipsum our goals Lorem ipsum our goals Lorem ipsum our goals Lorem ipsum our goals Lorem ipsum our goals Lorem ipsum our goals', 'Our Goals', '', 'inherit', 'closed', 'closed', '', '16-revision-v1', '', '', '2017-12-27 01:25:31', '2017-12-27 01:25:31', '', 16, 'http:nuevo.com/16-revision-v1/', 0, 'revision', '', 0),
(18, 1, '2017-12-27 01:41:17', '2017-12-27 01:41:17', 'Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum', 'Cookie Policy', '', 'publish', 'closed', 'closed', '', 'cookie-policy', '', '', '2017-12-27 01:41:17', '2017-12-27 01:41:17', '', 11, 'http:nuevo.com/?page_id=18', 0, 'page', '', 0),
(19, 1, '2017-12-27 01:41:17', '2017-12-27 01:41:17', 'Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum', 'Cookie Policy', '', 'inherit', 'closed', 'closed', '', '18-revision-v1', '', '', '2017-12-27 01:41:17', '2017-12-27 01:41:17', '', 18, 'http:nuevo.com/18-revision-v1/', 0, 'revision', '', 0),
(21, 1, '2017-12-28 01:11:44', '2017-12-28 01:11:44', ' ', '', '', 'publish', 'closed', 'closed', '', '21', '', '', '2017-12-28 01:13:03', '2017-12-28 01:13:03', '', 0, 'http:nuevo.com/?p=21', 1, 'nav_menu_item', '', 0),
(24, 1, '2017-12-28 01:11:45', '2017-12-28 01:11:45', ' ', '', '', 'publish', 'closed', 'closed', '', '24', '', '', '2017-12-28 01:13:03', '2017-12-28 01:13:03', '', 0, 'http:nuevo.com/?p=24', 2, 'nav_menu_item', '', 0),
(28, 1, '2017-12-28 01:12:24', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2017-12-28 01:12:24', '0000-00-00 00:00:00', '', 0, 'http:nuevo.com/?p=28', 1, 'nav_menu_item', '', 0),
(29, 1, '2017-12-28 01:12:25', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2017-12-28 01:12:25', '0000-00-00 00:00:00', '', 0, 'http:nuevo.com/?p=29', 1, 'nav_menu_item', '', 0),
(30, 1, '2017-12-29 00:17:02', '2017-12-29 00:17:02', '', 'Home', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2017-12-29 00:17:02', '2017-12-29 00:17:02', '', 0, 'http:nuevo.com/?page_id=30', 0, 'page', '', 0),
(31, 1, '2017-12-29 00:17:02', '2017-12-29 00:17:02', '', 'Home', '', 'inherit', 'closed', 'closed', '', '30-revision-v1', '', '', '2017-12-29 00:17:02', '2017-12-29 00:17:02', '', 30, 'http:nuevo.com/30-revision-v1/', 0, 'revision', '', 0),
(32, 1, '2017-12-29 00:19:34', '2017-12-29 00:19:34', '', 'Blog', '', 'publish', 'closed', 'closed', '', 'blog', '', '', '2017-12-29 00:19:34', '2017-12-29 00:19:34', '', 0, 'http:nuevo.com/?page_id=32', 0, 'page', '', 0),
(33, 1, '2017-12-29 00:17:14', '2017-12-29 00:17:14', '', 'Blog', '', 'inherit', 'closed', 'closed', '', '32-revision-v1', '', '', '2017-12-29 00:17:14', '2017-12-29 00:17:14', '', 32, 'http:nuevo.com/32-revision-v1/', 0, 'revision', '', 0),
(34, 1, '2017-12-29 00:38:58', '2017-12-29 00:38:58', '', 'We won an award', '', 'publish', 'open', 'open', '', 'we-won-an-award', '', '', '2017-12-29 00:38:58', '2017-12-29 00:38:58', '', 0, 'http:nuevo.com/?p=34', 0, 'post', '', 0),
(35, 1, '2017-12-29 00:38:58', '2017-12-29 00:38:58', '', 'We won an award', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2017-12-29 00:38:58', '2017-12-29 00:38:58', '', 34, 'http:nuevo.com/34-revision-v1/', 0, 'revision', '', 0),
(36, 1, '2017-12-30 21:16:44', '2017-12-30 21:16:44', 'lorem ipsumlorem ipsumlorem ipsumlorem ipsumlorem ipsumlorem ipsumlorem ipsumlorem ipsumlorem ipsumlorem ipsumlorem ipsumlorem ipsumlorem ipsumlorem ipsumlorem ipsumlorem ipsumlorem ipsumlorem ipsumlorem ipsumlorem ipsumlorem ipsumlorem ipsumlorem ipsumlorem ipsumlorem ipsumlorem ipsumlorem ipsum', 'Math Meetup', '', 'publish', 'closed', 'closed', '', 'math-meetup', '', '', '2017-12-31 20:35:14', '2017-12-31 20:35:14', '', 0, 'http:nuevo.com/?post_type=event&#038;p=36', 0, 'event', '', 0),
(37, 1, '2017-12-30 21:17:12', '2017-12-30 21:17:12', 'qweqweqweqwewq', 'The science of cats', '', 'publish', 'closed', 'closed', '', 'the-science-of-cats', '', '', '2018-01-04 22:10:17', '2018-01-04 22:10:17', '', 0, 'http:nuevo.com/?post_type=event&#038;p=37', 0, 'event', '', 0),
(38, 1, '2017-12-30 21:17:33', '2017-12-30 21:17:33', 'lorem ipsumlorem ipsumlorem ipsumlorem ipsumlorem ipsumlorem ipsumlorem ipsumlorem ipsumlorem ipsumlorem ipsumlorem ipsumlorem ipsumlorem ipsumlorem ipsumlorem ipsum', 'Poetry day', '', 'publish', 'closed', 'closed', '', 'poetry-day', '', '', '2018-01-07 03:09:44', '2018-01-07 03:09:44', '', 0, 'http:nuevo.com/?post_type=event&#038;p=38', 0, 'event', '', 0),
(41, 1, '2017-12-31 00:37:46', '2017-12-31 00:37:46', '', 'Event Date', '', 'publish', 'closed', 'closed', '', 'acf_event-date', '', '', '2017-12-31 00:37:46', '2017-12-31 00:37:46', '', 0, 'http:nuevo.com/?post_type=acf&#038;p=41', 0, 'acf', '', 0),
(42, 1, '2017-12-31 20:43:51', '2017-12-31 20:43:51', '', 'Past Events', '', 'publish', 'closed', 'closed', '', 'past-events', '', '', '2017-12-31 20:43:51', '2017-12-31 20:43:51', '', 0, 'http:nuevo.com/?page_id=42', 0, 'page', '', 0),
(43, 1, '2017-12-31 20:43:51', '2017-12-31 20:43:51', '', 'Past Events', '', 'inherit', 'closed', 'closed', '', '42-revision-v1', '', '', '2017-12-31 20:43:51', '2017-12-31 20:43:51', '', 42, 'http:nuevo.com/42-revision-v1/', 0, 'revision', '', 0),
(46, 1, '2018-01-04 21:05:14', '2018-01-04 21:05:14', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.', 'Math', '', 'publish', 'closed', 'closed', '', 'math', '', '', '2018-01-08 01:31:05', '2018-01-08 01:31:05', '', 0, 'http:nuevo.com/?post_type=program&#038;p=46', 0, 'program', '', 0),
(47, 1, '2018-01-04 21:05:20', '2018-01-04 21:05:20', '222222', 'English', '', 'publish', 'closed', 'closed', '', 'english', '', '', '2018-01-04 22:09:38', '2018-01-04 22:09:38', '', 0, 'http:nuevo.com/?post_type=program&#038;p=47', 0, 'program', '', 0),
(48, 1, '2018-01-04 21:05:33', '2018-01-04 21:05:33', '', 'Biology', '', 'publish', 'closed', 'closed', '', 'biology', '', '', '2018-01-14 20:51:36', '2018-01-14 20:51:36', '', 0, 'http:nuevo.com/?post_type=program&#038;p=48', 0, 'program', '', 0),
(49, 1, '2018-01-04 21:05:40', '2018-01-04 21:05:40', '4444', '4', '', 'trash', 'closed', 'closed', '', '4__trashed', '', '', '2018-01-04 22:08:52', '2018-01-04 22:08:52', '', 0, 'http:nuevo.com/?post_type=program&#038;p=49', 0, 'program', '', 0),
(50, 1, '2018-01-04 21:05:46', '2018-01-04 21:05:46', '555', '555', '', 'trash', 'closed', 'closed', '', '555__trashed', '', '', '2018-01-04 22:08:48', '2018-01-04 22:08:48', '', 0, 'http:nuevo.com/?post_type=program&#038;p=50', 0, 'program', '', 0),
(51, 1, '2018-01-04 22:07:54', '2018-01-04 22:07:54', '', 'Related Program', '', 'publish', 'closed', 'closed', '', 'acf_related-program', '', '', '2018-01-05 23:43:35', '2018-01-05 23:43:35', '', 0, 'http:nuevo.com/?post_type=acf&#038;p=51', 0, 'acf', '', 0),
(52, 1, '2018-01-05 23:38:26', '2018-01-05 23:38:26', 'asdasdasdasdasd', 'Dr Mewsalot', '', 'publish', 'closed', 'closed', '', 'dr-mewsalot', '', '', '2018-01-06 00:31:29', '2018-01-06 00:31:29', '', 0, 'http:nuevo.com/?post_type=professor&#038;p=52', 0, 'professor', '', 0),
(53, 1, '2018-01-05 23:38:51', '2018-01-05 23:38:51', 'asdasdasdasdasdasdasd', 'Dr BarkSalot', '', 'publish', 'closed', 'closed', '', 'dr-barksalot', '', '', '2018-01-06 01:38:11', '2018-01-06 01:38:11', '', 0, 'http:nuevo.com/?post_type=professor&#038;p=53', 0, 'professor', '', 0),
(54, 1, '2018-01-06 00:26:23', '2018-01-06 00:26:23', '', 'barksalot', '', 'inherit', 'open', 'closed', '', 'barksalot', '', '', '2018-01-06 00:26:23', '2018-01-06 00:26:23', '', 53, 'http:nuevo.com/wp-content/uploads/2018/01/barksalot.jpg', 0, 'attachment', 'image/jpeg', 0),
(55, 1, '2018-01-06 00:27:46', '2018-01-06 00:27:46', '', 'meowsalot', '', 'inherit', 'open', 'closed', '', 'meowsalot', '', '', '2018-01-06 00:27:46', '2018-01-06 00:27:46', '', 52, 'http:nuevo.com/wp-content/uploads/2018/01/meowsalot.jpg', 0, 'attachment', 'image/jpeg', 0),
(56, 1, '2018-01-06 00:47:18', '2018-01-06 00:47:18', 'qweqweqweqew', 'Dr Froggerson', '', 'publish', 'closed', 'closed', '', 'dr-froggerson', '', '', '2018-01-06 00:47:18', '2018-01-06 00:47:18', '', 0, 'http:nuevo.com/?post_type=professor&#038;p=56', 0, 'professor', '', 0),
(57, 1, '2018-01-06 00:46:39', '2018-01-06 00:46:39', '', 'frog-bio', '', 'inherit', 'open', 'closed', '', 'frog-bio', '', '', '2018-01-06 00:46:39', '2018-01-06 00:46:39', '', 56, 'http:nuevo.com/wp-content/uploads/2018/01/frog-bio.jpg', 0, 'attachment', 'image/jpeg', 0),
(58, 1, '2018-01-06 01:32:10', '2018-01-06 01:32:10', '', 'Page Banner', '', 'publish', 'closed', 'closed', '', 'acf_page-banner', '', '', '2018-01-06 01:37:38', '2018-01-06 01:37:38', '', 0, 'http:nuevo.com/?post_type=acf&#038;p=58', 0, 'acf', '', 0),
(59, 1, '2018-01-06 01:35:05', '2018-01-06 01:35:05', '', 'field', '', 'inherit', 'open', 'closed', '', 'field', '', '', '2018-01-06 01:35:05', '2018-01-06 01:35:05', '', 53, 'http:nuevo.com/wp-content/uploads/2018/01/field.jpg', 0, 'attachment', 'image/jpeg', 0),
(60, 1, '2018-01-07 03:09:35', '2018-01-07 03:09:35', '', 'notebook', '', 'inherit', 'open', 'closed', '', 'notebook', '', '', '2018-01-07 03:09:35', '2018-01-07 03:09:35', '', 38, 'http:nuevo.com/wp-content/uploads/2017/12/notebook.jpg', 0, 'attachment', 'image/jpeg', 0),
(61, 1, '2018-01-08 00:07:12', '2018-01-08 00:07:12', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.', 'Downtown West', '', 'publish', 'closed', 'closed', '', 'downtown-west', '', '', '2018-01-08 01:25:22', '2018-01-08 01:25:22', '', 0, 'http:nuevo.com/?post_type=campus&#038;p=61', 0, 'campus', '', 0),
(62, 1, '2018-01-08 00:08:33', '2018-01-08 00:08:33', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur', 'Downtown East', '', 'publish', 'closed', 'closed', '', 'downtown-east', '', '', '2018-01-08 01:25:26', '2018-01-08 01:25:26', '', 0, 'http:nuevo.com/?post_type=campus&#038;p=62', 0, 'campus', '', 0),
(63, 1, '2018-01-08 00:14:35', '2018-01-08 00:14:35', '', 'Map Location', '', 'publish', 'closed', 'closed', '', 'acf_map-location', '', '', '2018-01-08 00:14:35', '2018-01-08 00:14:35', '', 0, 'http:nuevo.com/?post_type=acf&#038;p=63', 0, 'acf', '', 0),
(64, 1, '2018-01-08 01:25:09', '2018-01-08 01:25:09', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.', 'Downtown West', '', 'inherit', 'closed', 'closed', '', '61-autosave-v1', '', '', '2018-01-08 01:25:09', '2018-01-08 01:25:09', '', 61, 'http:nuevo.com/61-autosave-v1/', 0, 'revision', '', 0),
(65, 1, '2018-01-08 01:30:03', '2018-01-08 01:30:03', '', 'Related Campus(es)', '', 'publish', 'closed', 'closed', '', 'acf_related-campuses', '', '', '2018-01-08 01:30:03', '2018-01-08 01:30:03', '', 0, 'http:nuevo.com/?post_type=acf&#038;p=65', 0, 'acf', '', 0),
(66, 1, '2018-01-14 20:46:21', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2018-01-14 20:46:21', '0000-00-00 00:00:00', '', 0, 'http:nuevo.com/?p=66', 0, 'post', '', 0),
(67, 1, '2018-01-14 20:51:04', '2018-01-14 20:51:04', '', 'Main Body Content', '', 'publish', 'closed', 'closed', '', 'acf_main-body-content', '', '', '2018-01-14 20:51:04', '2018-01-14 20:51:04', '', 0, 'http:nuevo.com/?post_type=acf&#038;p=67', 0, 'acf', '', 0),
(68, 1, '2018-01-14 21:15:21', '2018-01-14 21:15:21', '', 'Search', '', 'publish', 'closed', 'closed', '', 'search', '', '', '2018-01-14 21:15:21', '2018-01-14 21:15:21', '', 0, 'http:nuevo.com/?page_id=68', 0, 'page', '', 0),
(69, 1, '2018-01-14 21:15:21', '2018-01-14 21:15:21', '', 'Search', '', 'inherit', 'closed', 'closed', '', '68-revision-v1', '', '', '2018-01-14 21:15:21', '2018-01-14 21:15:21', '', 68, 'http:nuevo.com/68-revision-v1/', 0, 'revision', '', 0),
(70, 1, '2018-01-14 21:16:54', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2018-01-14 21:16:54', '0000-00-00 00:00:00', '', 0, 'http:nuevo.com/?p=70', 0, 'post', '', 0),
(71, 1, '2018-01-16 23:32:38', '2018-01-16 23:32:38', '', 'My Notes', '', 'publish', 'closed', 'closed', '', 'my-notes', '', '', '2018-01-16 23:32:38', '2018-01-16 23:32:38', '', 0, 'http:nuevo.com/?page_id=71', 0, 'page', '', 0),
(72, 1, '2018-01-16 23:32:38', '2018-01-16 23:32:38', '', 'My Notes', '', 'inherit', 'closed', 'closed', '', '71-revision-v1', '', '', '2018-01-16 23:32:38', '2018-01-16 23:32:38', '', 71, 'http:nuevo.com/71-revision-v1/', 0, 'revision', '', 0),
(73, 1, '2018-01-16 23:45:32', '2018-01-16 23:45:32', 'ive learned nothing', 'Biology lecture #4', '', 'publish', 'closed', 'closed', '', 'biology-lecture-4', '', '', '2018-01-16 23:45:32', '2018-01-16 23:45:32', '', 0, 'http:nuevo.com/?post_type=note&#038;p=73', 0, 'note', '', 0),
(74, 1, '2018-01-16 23:46:09', '2018-01-16 23:46:09', 'dummy post', 'Math lectures #1', '', 'publish', 'closed', 'closed', '', 'math-lecture-1', '', '', '2018-01-17 01:23:40', '2018-01-17 01:23:40', '', 0, 'http:nuevo.com/?post_type=note&#038;p=74', 0, 'note', '', 0),
(75, 1, '2018-01-21 00:42:08', '2018-01-21 00:42:08', '', 'Liked Professor ID', '', 'publish', 'closed', 'closed', '', 'acf_liked-professor-id', '', '', '2018-01-21 00:42:08', '2018-01-21 00:42:08', '', 0, 'http:nuevo.com/?post_type=acf&#038;p=75', 0, 'acf', '', 0),
(76, 1, '2018-01-21 00:42:51', '2018-01-21 00:42:51', '', '', '', 'publish', 'closed', 'closed', '', '76', '', '', '2018-01-21 00:42:51', '2018-01-21 00:42:51', '', 0, 'http:nuevo.com/?post_type=like&#038;p=76', 0, 'like', '', 0) ;

#
# End of data contents of table `wp_posts`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_relationships`
#
INSERT INTO `wp_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(4, 1, 0),
(21, 2, 0),
(24, 2, 0),
(34, 3, 0) ;

#
# End of data contents of table `wp_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_taxonomy`
#
INSERT INTO `wp_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 2),
(2, 2, 'nav_menu', '', 0, 2),
(3, 3, 'category', '', 0, 1) ;

#
# End of data contents of table `wp_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `wp_termmeta`
#

DROP TABLE IF EXISTS `wp_termmeta`;


#
# Table structure of table `wp_termmeta`
#

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_termmeta`
#

#
# End of data contents of table `wp_termmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_terms`
#
INSERT INTO `wp_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'My Main Header Menu', 'my-main-header-menu', 0),
(3, 'Award', 'award', 0) ;

#
# End of data contents of table `wp_terms`
# --------------------------------------------------------



#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_usermeta`
#
INSERT INTO `wp_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'Marcos'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'comment_shortcuts', 'false'),
(7, 1, 'admin_color', 'fresh'),
(8, 1, 'use_ssl', '0'),
(9, 1, 'show_admin_bar_front', 'true'),
(10, 1, 'locale', ''),
(11, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(12, 1, 'wp_user_level', '10'),
(13, 1, 'dismissed_wp_pointers', ''),
(14, 1, 'show_welcome_panel', '1'),
(15, 1, 'session_tokens', 'a:1:{s:64:"45d35de0d43018b8770e80b88b9d7a19a5d88d1a7992ec539e78e0a36f7791a6";a:4:{s:10:"expiration";i:1516667997;s:2:"ip";s:9:"127.0.0.1";s:2:"ua";s:126:"Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36 OPR/50.0.2762.58";s:5:"login";i:1516495197;}}'),
(16, 1, 'wp_dashboard_quick_press_last_post_id', '66'),
(17, 1, 'community-events-location', 'a:1:{s:2:"ip";s:12:"192.168.95.0";}'),
(18, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";i:4;s:15:"title-attribute";}'),
(19, 1, 'metaboxhidden_nav-menus', 'a:1:{i:0;s:12:"add-post_tag";}'),
(20, 1, 'closedpostboxes_event', 'a:1:{i:0;s:11:"postexcerpt";}'),
(21, 1, 'metaboxhidden_event', 'a:1:{i:0;s:7:"slugdiv";}'),
(22, 1, 'wp_user-settings', 'libraryContent=browse'),
(23, 1, 'wp_user-settings-time', '1515198446'),
(24, 2, 'nickname', 'kittydoe'),
(25, 2, 'first_name', ''),
(26, 2, 'last_name', ''),
(27, 2, 'description', ''),
(28, 2, 'rich_editing', 'true'),
(29, 2, 'comment_shortcuts', 'false'),
(30, 2, 'admin_color', 'fresh'),
(31, 2, 'use_ssl', '0'),
(32, 2, 'show_admin_bar_front', 'true'),
(33, 2, 'locale', ''),
(34, 2, 'wp_capabilities', 'a:1:{s:13:"event_planner";b:1;}'),
(35, 2, 'wp_user_level', '0'),
(36, 2, 'dismissed_wp_pointers', '') ;

#
# End of data contents of table `wp_usermeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_users`
#
INSERT INTO `wp_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'Marcos', '$P$BOB2dUxHUsR0Is.X.5iZo255OciUF80', 'marcos', 'donotrreply@gmail.com', '', '2017-12-14 00:36:05', '', 0, 'Marcos'),
(2, 'kittydoe', '$P$BwxapWFiJbXlr1oPImX5t2h.H8Rdyr.', 'kittydoe', 'kittydoe@learnwebcode.com', '', '2018-01-16 02:05:45', '1516068347:$P$BUFxuy2gQExLQCAMBo3QpRRdsv9a29.', 0, 'kittydoe') ;

#
# End of data contents of table `wp_users`
# --------------------------------------------------------

#
# Add constraints back in and apply any alter data queries.
#

